#' Molecules read into R in sdf format
#'
#' This object contains molecules read into R using the 'load.molecules' function
#'
#' @name mols
#' @docType data
#' @keywords datasets
NULL
